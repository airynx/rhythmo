package com.rhythmo.rhythmobackend.controller;

import com.rhythmo.rhythmobackend.consts.ApiPath;
import com.rhythmo.rhythmobackend.dto.ActivityForm;
import com.rhythmo.rhythmobackend.exceptions.NoSuchEntityException;
import com.rhythmo.rhythmobackend.model.Activity;
import com.rhythmo.rhythmobackend.model.User;
import com.rhythmo.rhythmobackend.repository.ActivityRepository;
import com.rhythmo.rhythmobackend.repository.UserRepository;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(ApiPath.ACTIVITY)
@AllArgsConstructor
public class ActivityController {
    private UserRepository userRepository;
    private ActivityRepository activityRepository;
    private ActivityModelAssembler activityModelAssembler;


    @PostMapping
    public ResponseEntity<EntityModel<Activity>> create(@Valid @RequestBody ActivityForm activityForm, @AuthenticationPrincipal Jwt authorJwt) { // todo: how to no jwt
        String jwtSubject = authorJwt.getSubject();
        User author = userRepository.getUserByUsername(jwtSubject).orElseThrow(() -> new NoSuchEntityException(jwtSubject));
        EntityModel<Activity> activityModel = activityModelAssembler.toModel(
                activityRepository.save(
                        new Activity(activityForm.name(), activityForm.type(), activityForm.url(), author)
                )
        );
        return ResponseEntity
                .created(activityModel.getRequiredLink(IanaLinkRelations.SELF).toUri())
                .body(activityModel);
    }

    @GetMapping("/{id}")
    public EntityModel<Activity> getById(@PathVariable("id") Long id) {
        return activityModelAssembler.toModel(
                activityRepository
                        .findById(id)
                        .orElseThrow(() -> new NoSuchEntityException(id))
        );
    }

    @GetMapping("/user/{id}")
    public CollectionModel<EntityModel<Activity>> getUsersActivities(@PathVariable("id") Long id) {
        User user = userRepository
                .findById(id)
                .orElseThrow(() -> new NoSuchEntityException(id));
        return CollectionModel.of(
                activityRepository.findByAuthor(user).stream()
                        .map(activityModelAssembler::toModel)
                        .toList()
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") Long id, @AuthenticationPrincipal User user) {
        Activity activity = activityRepository.findById(id).orElseThrow(() -> new NoSuchEntityException(id));
        if (!activity.getAuthor().getId().equals(user.getId())) {
            throw new AccessDeniedException("Can not delete not yours activity.");
        }
        activityRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
