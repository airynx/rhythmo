package com.rhythmo.rhythmobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class RhythmoBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(RhythmoBackendApplication.class, args);
    }

}
