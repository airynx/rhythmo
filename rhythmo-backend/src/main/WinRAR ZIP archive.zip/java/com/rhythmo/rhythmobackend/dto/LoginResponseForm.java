package com.rhythmo.rhythmobackend.dto;

public record LoginResponseForm(String token, long expirationTime) {
}
